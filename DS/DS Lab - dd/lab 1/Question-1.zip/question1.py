#Insertion sort - Question 1 

#Number of list elements
k = int(input("Enter the number of elements: "))

#Creating an empty list
num = []

#Assuming the input is only integers, Getting the elements of the list
for i in range(0,k):
    element = int(input())
    num.append(element)

#printing the list for verification
print("Your list is", num)

#defining key and index elements
key = 0
temp = 0

#assuming num[0] is already sorted, we move on to num[1]
i = 0

#temp = x, x = y, y = temp -> Swapping the numbers

'''
Algorithm for Insertion Sort:
1)Assume the first element is already sorted
2)Store the next element in a key
3)Compare the key with the sorted array
4)If the element is smaller than the current element, then move to the next element. 
otherwise shift the greater elements in the array towards the right.
5)Insert the value.
6)Repeat it untill the array is sorted.
'''

for i in range(0,k):
    key = num[i]
    j = i
    while j > 0  and num[j-1] > key:
        num[j] = num[j-1]
        j = j-1
        num[j] = key
        
   

#Printing the final list
print(num)