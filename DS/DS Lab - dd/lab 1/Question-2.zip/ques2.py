#Binary Search - Question 2 [Assuming the input is only integers]
'''
Algorithm for Binary search
1) Take the list and sort it in ascending order
2) Get the input y that is to be searched. 
3) Compare y with the middle number of the list. 
If it is higher move on to the right and continue the process until its found.
Else, move on to the list in the left
'''

def binary_search(arr, low, high, y):
    if high >= low:
        mid = (high + low) // 2
        
        if arr[mid] == y:
            return mid
        
        elif arr[mid] > y:
            return binary_search(arr, low, mid - 1, y)
        
        else:
            return binary_search(arr, mid + 1, high, y)
    else:
        return -1
       
#Number of elements in the list
k = int(input("Enter the number of integers: "))
array=[]

#Adding numbers to the list
for o in range (k):
    num = int(input())
    array.append(num)

#printing the array
print(array)

print("The sorted array is: ")
arr = sorted(array)
print(arr)

#Getting y value
y = int(input("Enter the number that needs to be searched: "))
result = binary_search(arr, 0, len(arr)-1, y)

#final outcome
if result != -1:
    print("Element is present at index", str(result))

else:
    print("Element is not present in array")