import pandas as pd

#reading the file
df = pd.read_csv('diabetes.csv')

#getting relevant data
terms = (df['Glucose'] > 120) & (df['BloodPressure'] > 90) & (df['SkinThickness'] > 30) & (df['Insulin'] > 150) & (df['BMI'] > 25)
final = df[terms]

#finding the probability and printing it
probability = final['Outcome'].mean()
print(f"Probability of diabetes: {probability:.2f}")