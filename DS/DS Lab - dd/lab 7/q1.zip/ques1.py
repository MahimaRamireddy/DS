import pandas as pd

#reading data from .csv file
df = pd.read_csv('diabetes.csv')

#making a menu function
def menu():
    print("Choose from the given options")
    print("1)Probability of diabetes - type 1 to select")
    print("2)Probability of diabetes based on age - type a,b,c,d depending on choice to select")
    print("a) Age above 50")
    print("b) Age between 40 and 50")
    print("c) Age between 30 and 40")
    print("d) Age less than 30")
    print("3)Exit")
    
#loop to continue menu untill required
while True:
    menu()
    choice = input("Option: ")
    
    #Finding probability for specific age groups 
    if choice == 'a':
        print("Age above 50")
        prob = df[df['Age'] > 50]['Outcome'].mean()
        print(f"The probability is: {prob:.2f}\n")
        
    elif choice == 'b':
        print("Age between 40 and 50")
        prob = df[(df['Age'] >= 41) & (df['Age'] <= 50)]['Outcome'].mean()
        print(f"The probability is: {prob:.2f}\n")
        
    elif choice == 'c':
        print("Age between 30 and 40")
        prob = df[(df['Age'] >= 31) & (df['Age'] <= 40)]['Outcome'].mean()
        print(f"The probability is: {prob:.2f}\n")
        
    elif choice == 'd':
        print("Age less than 30")
        prob = df[df['Age'] <= 30]['Outcome'].mean()
        print(f"The probability is: {prob:.2f}\n")
    
    #Finding probability in whole data set     
    elif choice == '1':
        print("Probability of diabetes")
        prob = df['Outcome'].mean()
        print(f"The probability of diabetes given the dataset is: {prob:.2f} \n")
        
    else:
        print("Exitting...")
        break
