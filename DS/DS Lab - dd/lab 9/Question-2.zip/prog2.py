
import pandas as pd

# Load the CSV file into a DataFrame
file_path = 'diabetes1.csv'
df = pd.read_csv(file_path)

# Replace 0 values with the mean of the specific column
df.replace({'Glucose': {0: df['Glucose'].mean()}}, inplace=True)
df.replace({'BloodPressure': {0: df['BloodPressure'].mean()}}, inplace=True)
df.replace({'SkinThickness': {0: df['SkinThickness'].median()}}, inplace=True)
df.replace({'Insulin': {0: df['Insulin'].mean()}}, inplace=True)
df.replace({'BMI': {0: df['BMI'].mean()}}, inplace=True)

# Remove duplicates
df.drop_duplicates(inplace=True)

# Save the cleaned data to a new CSV file
cleaned_file_path = 'cleaned_diabetes.csv'
df.to_csv(cleaned_file_path, index=False)

print('Data cleaning completed. Cleaned data saved to', cleaned_file_path)

# Display mean, median, mode, min, max, and std for all attributes excluding 'Outcome'
statistics = df.drop('Outcome', axis=1).describe().transpose()
print("Descriptive Statistics:")
print(statistics)

# Calculate correlation coefficient for 'Age' with all other attributes
age_correlation = df.drop('Outcome', axis=1).corrwith(df['Age'])
print("\nCorrelation coefficient for 'Age' with other attributes:")
print(age_correlation)

# Calculate correlation coefficient for 'BMI' with all other attributes
bmi_correlation = df.drop('Outcome', axis=1).corrwith(df['BMI'])
print("\nCorrelation coefficient for 'BMI' with other attributes:")
print(bmi_correlation)

